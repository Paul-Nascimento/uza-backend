from datetime import date
from .services_gerais import (
    get_kpis,
    get_evolucao,
    get_top5_categorias,
    get_top5_projetos,
)


def get_visao_geral(date_from: date, date_to: date) -> dict:
    return {
        "kpis": get_kpis(date_from, date_to),
        "evolucao": get_evolucao(date_from, date_to),
        "top5_categorias": get_top5_categorias(date_from, date_to),
        "top5_projetos": get_top5_projetos(date_from, date_to),
    }   