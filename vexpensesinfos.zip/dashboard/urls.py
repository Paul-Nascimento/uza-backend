from django.urls import path
from .views import VisaoGeralView, FluxoCaixaView
from .views_despesas import DespesasView
from .views_projetos import ProjetosView
from .views_colaboradores import ColaboradoresView
from .views_filter_options import FilterOptionsView

urlpatterns = [
    path("visao-geral/",    VisaoGeralView.as_view()),
    path("despesas/",       DespesasView.as_view()),
    path("projetos/",       ProjetosView.as_view()),
    path("fluxo-caixa/",    FluxoCaixaView.as_view()),
    path("colaboradores/",  ColaboradoresView.as_view()),
    path("filter-options/", FilterOptionsView.as_view()),
]