from datetime import date
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .services_colaboradores import get_colaboradores


class ColaboradoresView(APIView):
    def get(self, request):
        try:
            hoje = date.today()
            date_from = date.fromisoformat(
                request.query_params.get("date_from", hoje.replace(day=1).isoformat())
            )
            date_to = date.fromisoformat(
                request.query_params.get("date_to", hoje.isoformat())
            )
            funcionario_id = request.query_params.get("user_id") or None
            if funcionario_id:
                funcionario_id = int(funcionario_id)

            data = get_colaboradores(date_from, date_to, funcionario_id)
            return Response(data)
        except ValueError as e:
            return Response({"error": f"Parâmetro inválido: {e}"}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)