from rest_framework.views import APIView
from rest_framework.response import Response

from contaazulinfos.models import CentroCusto, Categoria, Pessoa
from vexpensesinfos.models import TeamMember


class FilterOptionsView(APIView):
    def get(self, request):
        projetos = list(CentroCusto.objects.filter(ativo=True).values("id", "nome").order_by("nome"))
        categorias = list(Categoria.objects.all().values("id", "nome").order_by("nome"))
        pessoas = list(Pessoa.objects.filter(ativo=True).values("id", "nome").order_by("nome"))
        colaboradores = list(TeamMember.objects.filter(active=True).values("id", "name").order_by("name"))

        status_options = [
            {"id": "RECEBIDO",          "nome": "Recebido"},
            {"id": "ATRASADO",          "nome": "Atrasado"},
            {"id": "EM_ABERTO",         "nome": "Em aberto"},
            {"id": "PARCIALMENTE_PAGO", "nome": "Parcialmente pago"},
        ]

        return Response({
            "projetos":      projetos,
            "categorias":    categorias,
            "pessoas":       pessoas,
            "colaboradores": [{"id": c["id"], "nome": c["name"]} for c in colaboradores],
            "status":        status_options,
        })