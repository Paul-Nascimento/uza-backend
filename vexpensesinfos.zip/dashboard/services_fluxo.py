from decimal import Decimal
from datetime import date
from django.db.models import Sum

from contaazulinfos.models import ContaAReceber, ContaAPagar


def _to_decimal(value) -> Decimal:
    return Decimal(str(value)) if value else Decimal("0.00")


def _float(value) -> float:
    return float(_to_decimal(value))


# ── KPIs ───────────────────────────────────────────────────────────────────────

def get_kpis_fluxo(date_from: date, date_to: date) -> dict:
    entradas = ContaAReceber.objects.filter(
        data_alteracao__gte=date_from,
        data_alteracao__lte=date_to,
        status_traduzido="RECEBIDO",
    ).aggregate(total=Sum("pago"))["total"] or Decimal("0.00")

    saidas = ContaAPagar.objects.filter(
        data_alteracao__gte=date_from,
        data_alteracao__lte=date_to,
        status_traduzido="RECEBIDO",
    ).aggregate(total=Sum("pago"))["total"] or Decimal("0.00")

    entradas_dec = _to_decimal(entradas)
    saidas_dec = _to_decimal(saidas)
    saldo = entradas_dec - saidas_dec

    return {
        "entradas": float(entradas_dec),
        "saidas": float(saidas_dec),
        "saldo": float(saldo),
    }


# ── Gráfico: Evolução Mensal ───────────────────────────────────────────────────

def get_evolucao_mensal(date_from: date, date_to: date) -> list:
    """
    Agrupa entradas e saídas por mês (data_alteracao) dentro do período.
    Retorna um ponto por mês com entradas, saidas e saldo acumulado.
    """
    # Busca entradas agrupadas por mês
    entradas_qs = (
        ContaAReceber.objects.filter(
            data_alteracao__gte=date_from,
            data_alteracao__lte=date_to,
            status_traduzido="RECEBIDO",
        )
        .values("data_alteracao__year", "data_alteracao__month")
        .annotate(total=Sum("pago"))
        .order_by("data_alteracao__year", "data_alteracao__month")
    )

    # Busca saídas agrupadas por mês
    saidas_qs = (
        ContaAPagar.objects.filter(
            data_alteracao__gte=date_from,
            data_alteracao__lte=date_to,
            status_traduzido="RECEBIDO",
        )
        .values("data_alteracao__year", "data_alteracao__month")
        .annotate(total=Sum("pago"))
        .order_by("data_alteracao__year", "data_alteracao__month")
    )

    # Indexa por (ano, mês)
    map_entradas = {
        (row["data_alteracao__year"], row["data_alteracao__month"]): _float(row["total"])
        for row in entradas_qs
    }
    map_saidas = {
        (row["data_alteracao__year"], row["data_alteracao__month"]): _float(row["total"])
        for row in saidas_qs
    }

    # União de todos os meses presentes
    todos_meses = sorted(set(map_entradas.keys()) | set(map_saidas.keys()))

    MESES_PT = {
        1: "Jan", 2: "Fev", 3: "Mar", 4: "Abr",
        5: "Mai", 6: "Jun", 7: "Jul", 8: "Ago",
        9: "Set", 10: "Out", 11: "Nov", 12: "Dez",
    }

    saldo_acumulado = 0.0
    resultado = []
    for ano, mes in todos_meses:
        entrada = map_entradas.get((ano, mes), 0.0)
        saida = map_saidas.get((ano, mes), 0.0)
        saldo_acumulado += entrada - saida
        resultado.append({
            "month": f"{MESES_PT[mes]}/{str(ano)[2:]}",
            "entradas": entrada,
            "saidas": saida,
            "saldo": round(saldo_acumulado, 2),
        })

    return resultado


# ── Agregado ───────────────────────────────────────────────────────────────────

def get_fluxo_caixa(date_from: date, date_to: date) -> dict:
    return {
        "kpis": get_kpis_fluxo(date_from, date_to),
        "evolucao_mensal": get_evolucao_mensal(date_from, date_to),
    }