from datetime import date
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .services_fluxo import get_fluxo_caixa


class FluxoCaixaView(APIView):
    """
    GET /api/dashboard/fluxo-caixa/
    Query params:
      - date_from  YYYY-MM-DD
      - date_to    YYYY-MM-DD
    """

    def get(self, request):
        try:
            hoje = date.today()
            date_from = date.fromisoformat(
                request.query_params.get("date_from", hoje.replace(day=1).isoformat())
            )
            date_to = date.fromisoformat(
                request.query_params.get("date_to", hoje.isoformat())
            )

            data = get_fluxo_caixa(date_from, date_to)
            return Response(data)

        except ValueError as e:
            return Response({"error": f"Parâmetro inválido: {e}"}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)