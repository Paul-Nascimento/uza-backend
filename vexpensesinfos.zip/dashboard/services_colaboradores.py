from decimal import Decimal
from datetime import date, timedelta
from django.db.models import Sum

from vexpensesinfos.models import Expense


def _to_decimal(value) -> Decimal:
    return Decimal(str(value)) if value else Decimal("0.00")

def _float(value) -> float:
    return float(_to_decimal(value))


# ── KPIs ───────────────────────────────────────────────────────────────────────

def get_kpis_colaboradores(date_from: date, date_to: date, funcionario_id: int = None) -> dict:
    base = Expense.objects.filter(
        date__date__gte=date_from,
        date__date__lte=date_to,
        user__isnull=False,
    )
    if funcionario_id:
        base = base.filter(user_id=funcionario_id)

    total = base.aggregate(total=Sum("value"))["total"] or Decimal("0.00")
    total_dec = _to_decimal(total)

    num_colaboradores = base.values("user_id").distinct().count()
    media = (total_dec / num_colaboradores) if num_colaboradores > 0 else Decimal("0.00")

    maior = (
        base.values("user_id", "user__name")
        .annotate(total=Sum("value"))
        .order_by("-total")
        .first()
    )

    total_nao_aprovado = base.exclude(
        report_status="APROVADO"
    ).aggregate(total=Sum("value"))["total"] or Decimal("0.00")

    return {
        "total_gasto": _float(total_dec),
        "media_por_pessoa": _float(media),
        "maior_gasto_nome": maior["user__name"] if maior else "-",
        "maior_gasto_valor": _float(maior["total"]) if maior else 0.0,
        "total_nao_aprovado": _float(_to_decimal(total_nao_aprovado)),
    }


# ── Gráfico: Ranking por Colaborador ─────────────────────────────────────────

def get_ranking_colaboradores(date_from: date, date_to: date, funcionario_id: int = None) -> list:
    qs = Expense.objects.filter(
        date__date__gte=date_from,
        date__date__lte=date_to,
        user__isnull=False,
    )
    if funcionario_id:
        qs = qs.filter(user_id=funcionario_id)

    qs = (
        qs.values("user_id", "user__name", "report_status")
        .annotate(value=Sum("value"))
        .order_by("user__name")
    )

    colaboradores: dict = {}
    for row in qs:
        uid = row["user_id"]
        if uid not in colaboradores:
            colaboradores[uid] = {"name": row["user__name"]}
        status = row["report_status"] or "SEM_STATUS"
        colaboradores[uid][status] = _float(row["value"])

    return list(colaboradores.values())


# ── Heatmap: Gastos por Dia ───────────────────────────────────────────────────

def get_heatmap_dias(date_from: date, date_to: date, funcionario_id: int = None) -> list:
    qs = Expense.objects.filter(
        date__date__gte=date_from,
        date__date__lte=date_to,
        user__isnull=False,
    )
    if funcionario_id:
        qs = qs.filter(user_id=funcionario_id)

    map_dias = {
        row["date__date"]: _float(row["total"])
        for row in qs.values("date__date").annotate(total=Sum("value"))
    }

    resultado = []
    cursor = date_from
    while cursor <= date_to:
        resultado.append({
            "day": cursor.strftime("%d/%m/%Y"),
            "value": map_dias.get(cursor, 0.0),
        })
        cursor += timedelta(days=1)

    return resultado


# ── Agregado ───────────────────────────────────────────────────────────────────

def get_colaboradores(date_from: date, date_to: date, funcionario_id: int = None) -> dict:
    return {
        "kpis": get_kpis_colaboradores(date_from, date_to, funcionario_id),
        "ranking": get_ranking_colaboradores(date_from, date_to, funcionario_id),
        "heatmap": get_heatmap_dias(date_from, date_to, funcionario_id),
    }